Japanese Dosanko City Asset ReadMe

Powered by ZENRIN CO., LTD.
http://www.zenrin.co.jp/


-----------------------------------
Asset Information
-----------------------------------
File Name    :  JapaneseDosankoCity.unitypackage
Version Info.:  Ver. 1.0.0  
Release Date :  13th, May, 2015

< Version Info >
(13th, May, 2015) Ver. 1.0.0 : Initial Release.


-----------------------------------
File Structure
-----------------------------------
Assets
 --> ZRNAssets
    --> 006441_09646_1_1 (Japanese Dosanko City 3D-Model Assets)
       --> Documents  :  ReadMe file and License documents.
       --> Materials  :  City materials.
       --> Models     :  FBX model.
       --> Scenes     :  Scene files for demonstration.
       --> Shaders    :  Original shaders for Japanese Dosanko City.
	   --> Textures   :  Japanese Dosanko City emvironment textures.

***** Below folders are sample data created by another company
 --> PQAssets (These files of the foler are provided by Pocket Queries, Inc.)
    --> Query-Chan-SD
       —-> Animations :  Query-Chan SD mecanim animation controller.
       --> Documents  :  ReadMe file and License logo file.
       —-> Materials  :  Query-Chan SD body and face materials.
       --> Models     :  Query-Chan SD Fukuoka model.
       --> Prefabs    :  Query-Chan SD prefab for mecanim motion.
       --> Sapporo_Props : Sample 3D models of Hokkaido object.
       --> Scripts    :  Script files for Query-Chan SD controller and Game controller.
       --> Sounds     :  BGM sound file.( the theme of Query-Chan)
       --> Textures   :  Query-Chan SD body and face textures.

  Please See Below URL, If you would like to use Full version of Query-Chan model SD.
    https://www.assetstore.unity3d.com/#!/content/35616


-----------------------------------
Demo Scene
-----------------------------------
1. You would open below scene file.
     - sample.unity

2. Play game.