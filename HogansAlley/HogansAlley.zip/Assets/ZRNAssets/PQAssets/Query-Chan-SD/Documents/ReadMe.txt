Query-Chan SD Asset ReadMe

Powered by Pocket Queries, Inc.
http://www.pocket-queries.co.jp
http://www.query-chan.com


-----------------------------------
Asset Information
-----------------------------------
File Name    :  Query-Chan-SD.unitypackage
Version Info.:  Ver. 0.0.2 (Pre Release for Japanese Dosanko City)
Release Date :  13th, May, 2015

< Version Info >
(13th, Apr, 2015) Ver. 0.0.0 : Pre Release.
(27th, Apr, 2015) Ver. 0.0.1 : Pre Release for Japanese Matsuri City.
(13th, May, 2015) Ver. 0.0.2 : Pre Release for Japanese Dosanko City.


-----------------------------------
File Structure
-----------------------------------
Assets
 --> PQAssets
    --> Query-Chan-SD
       —-> Animations :  Query-Chan SD mecanim animation controller.
       --> Documents  :  ReadMe file and License logo file.
       —-> Materials  :  Query-Chan SD body and face materials.
       --> Models     :  Query-Chan SD Fukuoka model.
       --> Prefabs    :  Query-Chan SD prefab for mecanim motion.
       --> Sapporo_Props : Sample 3D models of Hokkaido object.
       --> Scripts    :  Script files for Query-Chan SD controller and Game controller.
       --> Sounds     :  BGM sound file.( the theme of Query-Chan)
       --> Textures   :  Query-Chan SD body and face textures.


-----------------------------------
Logo Icon File
-----------------------------------
You are free to use "Query-Chan Logo Image File" below.
We are glad that you use the logo image on your Game applications.

   Assets/PQAssets/Query-Chan-SD/Documents/Query-Chan_license_logo.png


-----------------------------------
Full Version of Query-Chan model SD
-----------------------------------
Please See Below URL, If you would like to use Full version of Query-Chan model SD.
  https://www.assetstore.unity3d.com/#!/content/35616